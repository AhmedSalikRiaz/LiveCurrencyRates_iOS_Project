//
//  Currency+CoreDataProperties.swift
//  emre.ahmet
//
//  Created by CTIS Student on 17.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//
//

import Foundation
import CoreData


extension Currency {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Currency> {
        return NSFetchRequest<Currency>(entityName: "Currency")
    }
  

    @NSManaged public var name: String?
    @NSManaged public var price: String?
 


}
