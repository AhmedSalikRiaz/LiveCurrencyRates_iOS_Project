//
//  DataSource.swift
//  TableViewMVC
//
//  Created by Syed Ali on 15/11/21.
//  Copyright © 2021 CTIS. All rights reserved.
//

import Foundation

class DataSource {
    var mCurrencyList: [Crypto] = []
    var price_for_3d: [String] = []
    init() {
        //        print("Inside init()")
        populateData()
    }
    
    func numbeOfItems(_ index: Int) -> Int {
        return mCurrencyList.count
    }
    
    // MARK:- Populate Data from plist
    func populateData() {
        if let mURL = URL(string: "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=true&price_change_percentage=24h") {
            if let data = try? Data(contentsOf: mURL) {
                
                // https://www.dotnetperls.com/guard-swift
                guard let json = try? JSON(data: data) else {
                    print("Error with JSON")
                    return
                }
                
                //            print(json[0]["price_change_percentage_24h"].description)
                
                let total = json.count
                //               print(total)
                
                for index in 0..<total {
                    let symbol = json[index]["symbol"].description
                    let name = json[index]["name"].description
                    let current_price = json[index]["current_price"].description
                    let image = json[index]["image"].description
                    let price_change_percentage_24h = json[index]["price_change_percentage_24h"].description
                    for cnt in 0..<3 {
                        let sparkling = json[index]["sparkline_in_7d"]["price"][cnt].description
                        price_for_3d.append(sparkling)
                    }
                    
                    let crypto = Crypto(symbol: symbol, name: name, image: image, current_price: current_price, price_change_percentage_24h: price_change_percentage_24h, price_for_3d: price_for_3d)
                    
                    
                    mCurrencyList.append(crypto)
                    price_for_3d.removeAll()
                }
            }
            else {
                print("NSdata error")
            }
        }
        else {
            print("NSURL error")
        }
    }
    
}
