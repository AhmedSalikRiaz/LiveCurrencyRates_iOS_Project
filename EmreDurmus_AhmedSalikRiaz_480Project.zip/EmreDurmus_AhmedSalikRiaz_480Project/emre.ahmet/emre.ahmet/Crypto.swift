//
//  Crypto.swift
//  emre.ahmet
//
//  Created by CTIS Student on 17.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import Foundation

class Crypto {

    let symbol: String?
    let name: String?
    let image: String?
    let current_price: String?
    let price_change_percentage_24h: String?
    let price_for_3d : [String]
    
    
    init(symbol: String, name: String, image: String, current_price: String, price_change_percentage_24h: String, price_for_3d: [String]) {
           
        self.symbol = symbol
        self.name = name
        self.image = image
        self.current_price = current_price
        self.price_change_percentage_24h = price_change_percentage_24h
        self.price_for_3d = price_for_3d

           
           
    }
    
}
