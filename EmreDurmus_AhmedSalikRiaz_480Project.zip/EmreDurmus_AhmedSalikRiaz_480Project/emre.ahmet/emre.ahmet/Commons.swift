//
//  Commons.swift
//  emre.ahmet
//
//  Created by CTIS Student on 17.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//
import UIKit
import CoreData
import Foundation

var mCurrency = [Currency]()
let mDataSource = DataSource()

func fetchData() -> [Currency] {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Currency")
    
    // Create a sort descriptor object that sorts on the "surname"
    // property of the Core Data object
    let sortDescriptor1 = NSSortDescriptor(key: "name", ascending: true)
    let sortDescriptor2 = NSSortDescriptor(key: "price", ascending: true)
    
    // Set the list of sort descriptors in the fetch request,
    // so it includes the sort descriptor
    fetchRequest.sortDescriptors = [sortDescriptor1, sortDescriptor2]
    
    // NSPredicate performs search operation
    // https://nspredicate.xyz
    /* let search = "ay"
     let mPredicate = NSPredicate(format: "name contains[c] %@", search)*/
    
    //fetchRequest.predicate = mPredicate
    
    do {
        let results = try context.fetch(fetchRequest)
        mCurrency = results as! [Currency]
        
    } catch let error as NSError {
        print("Could not fetch \(error), \(error.userInfo)")
    }
    return mCurrency
    
}
//insert
func saveNewItem(_ name : String, price : String) {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    // Create the new Student item
    let newStudentItem = Currency.createInManagedObjectContext(context,
                                                               name: name, price: price)
    
    // Update the array containing the table view row data
    fetchData()
    
    // Use Swift's FirstIndex function for Arrays to figure out the index of the newStudentItem
    // after it's been added and sorted in our mStudent array
    if let newStudentIndex = mCurrency.firstIndex(of: newStudentItem) {
        // Create an NSIndexPath from the newStudentIndex
        let newStudentItemIndexPath = IndexPath(row: newStudentIndex, section: 0)
        // Animate in the insertion of this row
        
        
        save()
    }
}
func UpdateData(name: String, price: String) {
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Currency")
    let cur_for_upd = mDataSource.mCurrencyList[0]
    //    print(cur_for_upd.current_price)
    fetchRequest.predicate = NSPredicate(format: "name == %@", cur_for_upd.name!)
    let result = try? managedObjectContext.fetch(fetchRequest)
    let resultData = result as! [Currency]
    for object in resultData {
        
        object.name = name
        object.price = price
    }
    do {
        try managedObjectContext.save()
        //           print(name + price)
        print("saved!")
    } catch let error as NSError  {
        print("Could not save \(error), \(error.userInfo)")
    }
}
func save() {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    do {
        try context.save()
    } catch let error as NSError  {
        print("Could not save \(error), \(error.userInfo)")
    }
}
