//
//  NormalCurrencyVC.swift
//  emre.ahmet
//
//  Created by CTIS Student on 17.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit
import SCLAlertView

class NormalCurrencyVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var mTableView: UITableView!
    
    
    var link = "http://data.fixer.io/api/latest?access_key=88456c7d348e816874813285ae79228b"
    
    var euro: NormalCurrency?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        fetchData_self()
    }
    
    func fetchData_self() {
        if let mURL = URL(string: link) {
            URLSession.shared.dataTask(with: mURL) { (data, response, error) in
                // guard let can also be used here
                if error  == nil {
                    do {
                        self.euro = try JSONDecoder().decode(NormalCurrency.self, from: data!)
                    } catch {
                        print("Error occured")
                    }
                    
                    // Be carful 200 means response is succesful but you may not receive any data due to api restriction
                    if let httpResponse = response as? HTTPURLResponse {
                        print("Response Code = \(httpResponse.statusCode)")
                    }
                    
                    DispatchQueue.main.async {
                        if let temp = self.euro?.base {
                            print("Base currency = \(temp)")
                        }
                        self.mTableView.reloadData()
                        
                    }
                }
                else {
                    print("Error occured")
                }
            }.resume()
        }
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let currecyFetched = euro  {
            print("Total Currencies = \(currecyFetched.rates.count)")
            return currecyFetched.rates.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        if let currecyFetched = euro {
            
            cell.textLabel?.text = Array(currecyFetched.rates.keys)[indexPath.row]
            cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 20.0)
            cell.textLabel?.textColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
            
            let selectedRate = Array(currecyFetched.rates.values)[indexPath.row]
            cell.detailTextLabel?.text = "€ \(String(format: "%.3f", selectedRate))"
            cell.detailTextLabel?.font = UIFont.boldSystemFont(ofSize: 18.0)
            cell.detailTextLabel?.textColor = #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)
        }
        
        return cell
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
