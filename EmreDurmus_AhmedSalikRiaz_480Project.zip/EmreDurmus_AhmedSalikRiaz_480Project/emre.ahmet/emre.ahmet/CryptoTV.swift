//
//  CryptoVCV.swift
//  emre.ahmet
//
//  Created by CTIS Student on 17.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit
import SCLAlertView
import AVFoundation
class CryptoTV: UIViewController,  UITableViewDataSource, UITableViewDelegate {
    let mDataSource = DataSource()
    var audioPlayer: AVAudioPlayer!
    @IBOutlet weak var mTableview: UITableView!
    var sound_name = "note1"
    var selectedSoundFileName = ""
    
    
    @IBAction func displayHighest(_ sender: UIBarButtonItem) {
        var currency_h : [Currency]?
        
        currency_h = fetchData()
        
        SCLAlertView().showInfo("Most Expensive Currency '" + currency_h![currency_h!.count-1].name! + "'", subTitle:  "Price: $ " + currency_h![currency_h!.count-1].price!)
        
    }
    
    @IBAction func sound_On(_ sender: UIBarButtonItem) {
        selectedSoundFileName = sound_name
        
        print(selectedSoundFileName)
        playSound()
    }
    func playSound() {
        
        let soundURL = Bundle.main.url(forResource: selectedSoundFileName, withExtension: "wav")
        audioPlayer = try! AVAudioPlayer(contentsOf: soundURL!)
        
        audioPlayer.play()
    }
    
    @IBAction func onLongPressGestureRecognizer(_ sender: UILongPressGestureRecognizer) {
        let touchPoint = sender.location(in: mTableview)
        var str = ""
        if let indexPath = mTableview.indexPathForRow(at: touchPoint) {
            let ar = mDataSource.mCurrencyList[indexPath.row].price_for_3d
            for index in 0..<ar.count {
                str.append("Day " + "\(index + 1)" + ": $" + ar[index].prefix(8) + "\n")
            }
            
            SCLAlertView().showInfo("3 Days Price History for " + mDataSource.mCurrencyList[indexPath.row].name!, subTitle:  str)
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mDataSource.mCurrencyList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTVC
        
        // Configure the cell...
        
        if let data = try? Data(contentsOf: URL(string: mDataSource.mCurrencyList[indexPath.row].image!)!) {
            cell.crypto_img.image = UIImage(data: data)
            
            //        cell.crypto_img.image = UIImage(data: Data(contentsOf: URL(string: mDataSource.mCurrencyList[indexPath.row].image!)!))
            cell.crypt_long_name.text = mDataSource.mCurrencyList[indexPath.row].name
            cell.crypt_short_name.text = mDataSource.mCurrencyList[indexPath.row].symbol
            /* cell.currency_price.text = "$" +  mDataSource.mCurrencyList[indexPath.row].current_price!
             cell.rate_on_24.text = mDataSource.mCurrencyList[indexPath.row].price_change_percentage_24h! + "%"*/
            
            if let string = mDataSource.mCurrencyList[indexPath.row].price_change_percentage_24h! as? String {
                cell.rate_on_24.text = string.prefix(7) + "%"
                
                if (string.prefix(1) == "-") {
                    cell.rate_on_24.textColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
                } else{
                    cell.rate_on_24.textColor = #colorLiteral(red: 0.2745098174, green: 0.4862745106, blue: 0.1411764771, alpha: 1)
                    
                }
            }
            if let string = mDataSource.mCurrencyList[indexPath.row].current_price! as? String {
                cell.currency_price.text = "$ " +  string.prefix(10)
                
            }
            
            
        }
        return cell
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mDataSource.populateData()
        var ar : [Currency]
        ar = fetchData()
        
        if(ar.count < 1) {
            saveNewItem(mDataSource.mCurrencyList[0].name!, price: mDataSource.mCurrencyList[0].current_price!)
        } else{
            
            UpdateData(name: mDataSource.mCurrencyList[0].name!, price: mDataSource.mCurrencyList[0].current_price!)
        }
        
        
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
