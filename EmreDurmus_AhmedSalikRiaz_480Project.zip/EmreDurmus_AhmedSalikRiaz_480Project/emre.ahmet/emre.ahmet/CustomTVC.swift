//
//  CustomTVC.swift
//  emre.ahmet
//
//  Created by CTIS Student on 17.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//

import UIKit

class CustomTVC: UITableViewCell {
  

    @IBOutlet weak var crypto_img: UIImageView!
       
    @IBOutlet weak var crypt_long_name: UILabel!
        
    @IBOutlet weak var crypt_short_name: UILabel!
    
    @IBOutlet weak var currency_price: UILabel!
    
    @IBOutlet weak var rate_on_24: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
