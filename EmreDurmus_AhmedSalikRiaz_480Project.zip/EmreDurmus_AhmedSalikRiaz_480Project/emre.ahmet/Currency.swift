//
//  Currency+CoreDataClass.swift
//  emre.ahmet
//
//  Created by CTIS Student on 17.12.2022.
//  Copyright © 2022 CTIS. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Currency)
public class Currency: NSManagedObject {
    
    class func createInManagedObjectContext(_ context: NSManagedObjectContext, name: String, price: String) -> Currency {
          let currencyObject = NSEntityDescription.insertNewObject(forEntityName: "Currency", into: context) as! Currency
          currencyObject.name = name
          currencyObject.price = price
          
          
          return currencyObject
      }
}
